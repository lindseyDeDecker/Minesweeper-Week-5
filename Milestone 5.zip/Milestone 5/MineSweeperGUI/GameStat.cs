﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeperGUI
{
    public class GameStat
    {
        public int score { get; set; }
        public int id { get; set; }
        public string name { get; set; }
        public DateTime date { get; set; }
        public GameStat()
        {
            score = 0;
            id = 0;
            name = "";
            date = DateTime.Now;
        }
    }
}
