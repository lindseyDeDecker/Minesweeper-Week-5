﻿using Microsoft.VisualBasic.ApplicationServices;
using MineSweeperGUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Formats.Asn1.AsnWriter;

namespace MineSweeperGUI
{
    public partial class FrmScores : Form
    {
        GameStat gameStat;
        BindingSource bindingSource = new BindingSource();
        public static List<GameStat> statList = new List<GameStat>();

        public FrmScores(string name, int score)
        {
            InitializeComponent();
            gameStat = new GameStat();
            gameStat.name = name;
            gameStat.score = score;
            gameStat.date = DateTime.Now;
            gameStat.id = statList.Count + 1;
            statList.Add(gameStat);
        }

        private void FrmScores_Load(object sender, EventArgs e)
        {
            
            bindingSource.DataSource = statList;
            dgvScores.DataSource = bindingSource;

            using (StreamReader reader = new StreamReader("C:\\Users\\kydec\\Desktop\\Lindsey School\\CST - 250\\Week 1\\Milestone 1\\MineSweeperGUI\\scores.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) !=null)
                {
                    var values = line.Split("|");
                    var stat = new GameStat()
                    {
                        id = int.Parse(values[0]),
                        name = values[1],
                        score = int.Parse(values[2]),
                        date = DateTime.Parse(values[3])
                    };
                    statList.Add(stat);
                }
            }
            SortByName();
        }

        private void UpdateFile()
        {
            using (StreamWriter writer = new StreamWriter("C:\\Users\\kydec\\Desktop\\Lindsey School\\CST - 250\\Week 1\\Milestone 1\\MineSweeperGUI\\scores.txt"))
            {
                foreach (var stat in statList)
                {
                    string line = $"{stat.id}|{stat.name}|{stat.score}|{stat.date}";
                    writer.WriteLine(line);
                }
            }
                
        }
        private void SortByName()
        {
            statList = statList.OrderBy(stat => stat.name).ToList();
            bindingSource.DataSource = statList;
        }
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateFile();
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SortByName();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dgvScores.DataSource = null;
            this.Close();
        }

        private void byNameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SortByName();
        }

        private void byScoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statList = statList.OrderByDescending(stat => stat.score).ToList();
            bindingSource.DataSource = statList;
        }

        private void byDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statList = statList.OrderByDescending(stat => stat.date).ToList();
            bindingSource.DataSource = statList;
        }
    }
}

